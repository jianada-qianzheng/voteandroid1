List of contents:


README.txt
weizhizhang-COMP3000-ass3.txt
Q2
 - 3000pc-fifo-modified2.c  
 - Makefile 
 - 3000pc-fifo2.diff
Q3
 - ones-modified3.c 
 - Makefile 
 - ones3.diff

To compile the program and run it, please follow the instruction blow:

Compile command line:

	gcc weizhi_zhang_3000test2.c


Then run program with the command line below:

	./a.out <test_file>

Compile command line:
	
	gcc weizhi_zhang_3000test5.c

Then run program with the command line below:

	./a.out <test_file>
